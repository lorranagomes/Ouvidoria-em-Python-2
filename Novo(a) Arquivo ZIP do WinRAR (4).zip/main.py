#fase 03 da ouvidoria
#GRUPO: Lorrana Gomes, Juan Amaral e Douglas Rodrigues


from OperacoesSQL import *
from Ocorrencias import *

bancoDeDados = BancoDeDados

conexao = BancoDeDados.abrirBancoDados( 'localhost', 'root', 'lors12', 'ouvidoria' )

listaTipos = ['Reclamação', 'Sugestão', 'Elogio'] 
opcao = 0

while opcao != 5:
    print("\n                 MENU              ")
    print("-" * 42)
    print('1) Listar todas as ocorrência')
    print('2) Adicionar uma nova ocorrência')
    print('3) Pesquisar ocorrência por código')
    print('4) Remover ocorrência por código')
    print('5) Sair')
    print("-" * 42)

    opcao = int(input('Digite a opção do menu: '))

    if opcao < 1 or opcao > 5: 
        print('\nNão existe essa opção no menu, tente novamente!') 

    elif opcao == 1:
        filtro = 0
        while filtro < 1 or filtro > 4: 
            filtro = int(input('\nDeseja filtrar por:\n1) Reclamação\n2) Sugestão\n3) Elogio\n4) Todas\nDigite seu filtro:'))
            if filtro < 1 or filtro > 4: 
                print('\nTipo de ocorrência inválid!')
        if filtro == 1 :
            sql = "SELECT * FROM ocorrencias where categoria = 'Reclamação'"
            resultado = bancoDeDados.listarBancoDados(conexao, sql)
            print("-" * 42)
            print('Lista de todas reclamações:')
            print("-" * 42)
            if len(resultado) == 0:
                print('\nNenhuma ocorrência registrada!')
            else:
                for i in resultado:
                    elemento = str('Código: {}\nNome: {}\nDescrição: {}\n'.format(i[0], i[1], i[3]))
                    print(elemento)
        if filtro == 2 :
            sql = "SELECT * FROM ocorrencias where categoria = 'Sugestão'"
            resultado = bancoDeDados.listarBancoDados(conexao,sql)  
            print("-" * 42)
            print('\nLista de todas sugestões:')
            print("-" * 42)
            if len(resultado) == 0:
                print('\nNenhuma ocorrência registrada!')
            else:
                for i in resultado:
                    elemento = str('Código: {}\nNome: {}\nDescrição: {}\n'.format(i[0], i[1], i[3]))
                    print(elemento) 
        if filtro == 3 :
            sql = "SELECT * FROM ocorrencias where categoria = 'Elogio'"
            resultado = bancoDeDados.listarBancoDados(conexao,sql)  
            print("-" * 42)
            print('\nLista de todos elogios:')
            print("-" * 42)
            if len(resultado) == 0:
                print('\nNenhuma ocorrência registrada!')
            else:
                for i in resultado:
                    elemento = str('Código: {}\nNome: {}\nDescrição: {}\n'.format(i[0], i[1], i[3]))
                    print(elemento) 
        if filtro == 4 :
            print("-" * 42)
            print('Lista de todas ocorrências:')
            print("-" * 42)
            sql = "SELECT * FROM ocorrencias"
            resultado = bancoDeDados.listarBancoDados(conexao, sql)
            if len(resultado) == 0:
                print('\nNenhuma ocorrência registrada!')
            else:
                for i in resultado:
                    elemento = str('Código: {}\nNome: {}\nCategoria da Manifestação: {}\nDescrição: {}\n'.format(i[0], i[1], i[2], i[3]))
                    print(elemento)

    elif opcao == 2:
        categoria = 0
        nome = input('\nDigite o nome: ')
        while categoria < 1 or categoria > 3: 
            categoria = int(input('\nTipos de ocorrências:\n1) Reclamação\n2) Sugestão\n3) Elogio\nDigite o tipo da sua ocorrência:'))
            if categoria < 1 or categoria > 3: 
                print('\nTipo de ocorrência inválida!')
        descricao = input('\nDigite a descrição: ')
        
        ocorrencia = Ocorrencia(nome, listaTipos[categoria-1], descricao)
        
        sql = "INSERT INTO ocorrencias (nome, categoria, descricao) VALUES (%s, %s, %s)"
        dados = (ocorrencia.nome, ocorrencia.categoria, ocorrencia.descricao)
        bancoDeDados.insertNoBancoDados(conexao,sql,dados)
        print('\nOcorrência cadastrada com sucesso!')
    
    elif opcao == 3:
        codigo = input('\nDigite o código da sua ocorrência: ')
        sql = "SELECT * FROM ocorrencias where id = {}".format(codigo)
        resultado = bancoDeDados.listarBancoDados(conexao,sql)
        
        if resultado:
            for i in resultado:
                elemento = str('\nCódigo: {}\nNome: {}\nDescrição: {}'.format(i[0], i[1], i[3]))
                print(elemento)
        else: 
            print('\nOcorrência não encontrada!')
    elif opcao == 4:
        sql = "SELECT * FROM ocorrencias"
        resultado = bancoDeDados.listarBancoDados(conexao,sql)
        print("-" * 42)
        print('Lista de todas reclamações:')
        print("-" * 42)
        if len(resultado) == 0:
                print('\nNenhuma ocorrência registrada!')
        else:
            for i in resultado:
                elemento = str('Código: {}\nNome: {}\nDescrição: {}\n'.format(i[0], i[1], i[3]))
                print(elemento)
            codigo = int(input('Digite o código da sua ocorrência: '))
            
            sql = "SELECT * FROM ocorrencias where id = {}".format(codigo)
            ocorrenciaPesquisada = bancoDeDados.listarBancoDados(conexao,sql)
        
            if ocorrenciaPesquisada:
                sql = "DELETE FROM ocorrencias where id = %s"
                dados = (codigo,)
                bancoDeDados.excluirBancoDados(conexao, sql, dados)
                print('\nOcorrência removida com sucesso!')
            else: 
                print('\nCódigo de ocorrência inválida!')

print('\nSaindo...')
bancoDeDados.encerrarBancoDados(conexao)
