class Ocorrencia:
  
  def __init__(self, nome, categoria, descricao):
    self.nome = nome
    self.categoria = categoria
    self.descricao = descricao